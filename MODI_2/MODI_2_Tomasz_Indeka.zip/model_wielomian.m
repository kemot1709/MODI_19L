clear;
params;
stopien=10;

% error = model_show (daneucz, danewer, stopien)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% uruchamianie modelu dynamicznego %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
params;
stopien=10;

error = dynamic_show (danedynucz, danedynwer, stopien)
% Tomasz Indeka
% MODI, projekt 1, zadanie 11
% 
% Parametry do skryptu

% Parametry uk�adu
K=5;
T1=10;
T2=6;
alfa1=-0.9;
alfa2=1.37;
alfa3=-1.95;
alfa4=0.05;

StartDelay = 5;
StartValue = 0;
DelayValue = 1;
time = 100; % D�ugo�� symulacji

u=-3:0.5:3;
T=1;
ulin=0;